# 房东维修与维护责任

Landlord responsibilities for repair and maintenance of rental properties

来源：[NSW Government](https://www.nsw.gov.au/housing-and-construction/rules/landlord-obligations-and-responsibilities-for-rental-properties)
许可/权属：pending_review
适用范围：AU-NSW

[许可说明](https://www.nsw.gov.au/nsw-government/about-website/copyright)

## Landlord responsibilities for repair and maintenance of rental properties

Landlords have a responsibility to ensure that the property is fit to live in and meets health and safety laws.

Landlords are responsible for:

providing a property that is fit to live in

maintaining the rental property in a reasonable state of repair

providing and maintaining locks or other security devices to ensure the property is reasonably secure.

Landlords who do not comply with these obligations will be in breach of the tenancy agreement.

## Repairs and maintenance in a rental property

Landlords are responsible for repairing and maintaining the property so that it is in a reasonable state of repair, considering:

the age of the property

the amount of rent being paid

the prospective life of the property.

This does not mean that the property must be in perfect condition.

To learn more about landlord obligations for repairs and maintenance, visit Getting repairs done on a rental property .

## Landlords should deal with urgent repairs

Urgent repairs are considered to be repairs needed for serious issues that make a property unsafe or insecure or prevent access to essential services. That is, an issue that:

threatens a property's structural integrity.

poses a risk to lives.

makes a property unsafe or insecure.

prevents access to essential services.

Visit the Urgent repairs in residential rental properties page to see a list of what is considered an urgent repair.

## Landlords have certain responsibilities after a natural disaster

If a property has been affected by a natural disaster, such as a flood, bushfire or storm, landlords have certain responsibilities.

Serious storm, fire or flood damage are all considered to be urgent repairs and should be handled quickly.

Learn more about obligations for landlords after a rental property is affected by a natural disaster .

## Summary of key obligations for landlords

Landlords should repair a smoke alarm within certain time frames.

Landlords should conduct checks to ensure the smoke alarm is working.

Landlords should install or replace removable batteries every year.

If the rental property is in a strata scheme, the owners corporation may be responsible for repair and replacement of smoke alarms. Even if that is the case, landlords still have some obligations. See 'Smoke alarms in strata schemes' below.

## When are smoke alarms considered not working

The smoke alarm is removed and not replaced with a working smoke alarm.

The smoke alarm does not work (for example because the battery needs to be replaced).

The smoke alarm is malfunctioning (for example due to accumulated dust, insects, airborne contaminants or corrosion of electrical circuitry).

## Smoke alarms in strata schemes

Landlords with properties in a strata scheme have an obligation to ensure smoke alarms installed in the property are working. If the owners corporation is responsible for the repair and replacement of smoke alarms, landlords may have some different obligations relating to smoke alarms.

Visit the Smoke alarms in a rental property page to learn more about landlord obligations and smoke alarms, including in strata schemes.

## Non-urgent repairs

A landlord or agent is responsible for arranging non-urgent repairs needed to comply with the landlord's obligation to maintain a rental property in a reasonable state of repair.

A tenant must have written permission 'to carry out repairs to a rental property, including agreement on any reimbursement for costs, from the landlord, except for urgent repairs and some smoke alarm repairs, but tenants need to follow the requirements for those repairs.

## Meeting health and safety laws for a rental property

Landlords have a responsibility to ensure the property meets health and safety laws.

Meeting health and safety laws is a term of every tenancy agreement, and landlords who do not comply with these obligations will be in breach of the agreement.

Learn more about health and safety in a rental home .

## Resolving a repair, maintenance or damage dispute with a tenant

It is always best for landlords or an agent to try and seek a resolution with a tenant . If an issue cannot be resolved, a landlord can:

contact Fair Trading’s tenancy complaints and disputes service

lodge an application directly with the NSW Civil and Administrative Tribunal (NCAT).

In some situations, Fair Trading may issue a rectification order to landlords to undertake repairs, or to tenants to fix damage.

## Get help from NSW Fair Trading

Ask a question, get support, make a complaint, give feedback or get help with a dispute on matters relating to residential tenancies.

NSW Fair Trading call centre: 13 32 20

Monday to Friday, 8:30am-5pm

Make a tenancy or other real estate related enquiry at NSW Fair Trading

Provide feedback or make a complaint to NSW Fair Trading

Get information and advice about dealing with tenancy disputes

## Legislation supporting this page

Security and safety of residential premises, Part 3 Division 7 Residential Tenancies Act 2010

Landlord’s general obligations for residential premises, Section 52, Residential Tenancies Act 2010

